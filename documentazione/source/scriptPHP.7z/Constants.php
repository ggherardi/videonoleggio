<?php
class PermissionsConstants {
    const ADDETTO = 10;
    const RESPONSABILE = 20;
    const PROPRIETARIO = 30;
}
?>