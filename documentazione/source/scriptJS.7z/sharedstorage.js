class SharedStorage {
    constructor() {
        this.loginContext = null;
    }
}

sharedStorage = new SharedStorage();